package slotMachine;
import java.util.HashMap;
import javafx.scene.image.Image;
public class SymboleWild extends Symbole {
    public SymboleWild(String nom, float spawnProbability, Multiplicateur multipliers, int taille, Image image) {
        super(nom, spawnProbability, multipliers, taille, image);
    }
    // Ajouter des méthodes spécifiques si nécessaire
}
