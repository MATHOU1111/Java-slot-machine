package slotMachine;
/*
import java.util.ArrayList;
import java.util.Random;

public class Grille {
    private ArrayList<ArrayList<Symbole>> cases;

    public Grille() {
        cases = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            cases.add(new ArrayList<>());
            for (int j = 0; j < 5; j++) {
                cases.get(i).add(null); // Initialiser toutes les cases à null
            }
        }
    }

    public void genererSymbolesAleatoires() {
        Random random = new Random();
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 5; j++) {
                // Générer un symbole aléatoire et l'ajouter à la case correspondante
                int symboleIndex = random.nextInt(SymboleFactory.NB_SYMBOLES);
                cases.get(i).set(j, SymboleFactory.getSymbole(symboleIndex));
            }
        }
    }

    // Implémenter les autres méthodes de la classe Grille selon les besoins
}
*/


