package slotMachine;
import java.util.HashMap;
import javafx.scene.image.Image;
public class SymboleMega extends Symbole {
    public SymboleMega(String nom, float spawnProbability, Multiplicateur multipliers, int taille, Image image) {
        super(nom, spawnProbability, multipliers, taille, image);
    }

    public void detruireLigne() {
        // Implémenter la logique pour détruire la ligne de symboles
    }

    public void augmenterMultiplicateur() {
        // Implémenter la logique pour augmenter le multiplicateur
    }
}